
library(xmsPANDA)
source("/Users/karanuppal/Documents/Emory/JonesLab/Projects/DifferentialExpression/xmsPaNDA/xmsPANDA_v1.0.6.48.R")


##training set files###
feature_table_file="/Users/karanuppal/Documents/Emory/JonesLab/Projects/HainesAMD/testv1.0.6.26traintest0.7_rferflimmaplsmethodsmin1var100iter0.3calibB_final/train_selected_data_carnitines.csv"
class_labels_file="/Users/karanuppal/Documents/Emory/JonesLab/Projects/HainesAMD/testv1.0.6.26traintest0.7_rferflimmaplsmethodsmin1var100iter0.3calibB_final/train_classlabels_data.csv"
###################

##test set files### Same files are used in this example
testfeature_table_file="/Users/karanuppal/Documents/Emory/JonesLab/Projects/HainesAMD/testv1.0.6.26traintest0.7_rferflimmaplsmethodsmin1var100iter0.3calibB_final/test_selected_data_carnitines.csv"
testclass_labels_file="/Users/karanuppal/Documents/Emory/JonesLab/Projects/HainesAMD/testv1.0.6.26traintest0.7_rferflimmaplsmethodsmin1var100iter0.3calibB_final/test_classlabels_data.csv"
###############

##Read files####
featuretable<-read.csv(feature_table_file) #read.table(feature_table_file,sep="\t",header=TRUE)
testfeaturetable<-read.csv(testfeature_table_file) #read.table(testfeature_table_file,sep="\t",header=TRUE)

train_mzrt<-paste(featuretable[,1],"_",featuretable[,2],sep="")

test_mzrt<-paste(testfeaturetable[,1],"_",testfeaturetable[,2],sep="")

match_mzrt<-match(train_mzrt,test_mzrt)

if(length(which(is.na(match_mzrt)==TRUE))>0){
    
    stop("Train and test set variable names do not match.")
}

if(length(which(duplicated(train_mzrt)==TRUE))>0){
featuretable<-featuretable[-which(duplicated(train_mzrt)==TRUE),]
testfeaturetable<-testfeaturetable[-which(duplicated(test_mzrt)==TRUE),]

}

featuretable<-unique(featuretable)
testfeaturetable<-unique(testfeaturetable)

classlabels<-read.csv(class_labels_file) #read.table(class_labels_file,sep="\t",header=TRUE)
testclasslabels<-read.csv(testclass_labels_file) #read.table(testclass_labels_file,sep="\t",header=TRUE)


################

classlabels<-classlabels[,2] #column with class information
testclasslabels<-testclasslabels[,2] #column with class information

kfold=10 #dim(featuretable[,-c(1:2)])[2] #LOOCV recommended for only small studies N<30; or can be set to 5 or 10 for k-fold CV

errortype="BAR"; #other options: "AUC", "total"


pdf("testacc_carnitines.pdf")

res<-get_classification.accuracy(kfold=kfold,featuretable=featuretable,classlabels=classlabels,classifier="svm",testfeaturetable=testfeaturetable,testclasslabels=testclasslabels,errortype="BAR",kernelname="radial")

print(res)

dev.off()


